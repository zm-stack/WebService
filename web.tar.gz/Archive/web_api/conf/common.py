#!/usr/bin/env python2
# -*- coding: utf-8 -*-

EVM_PATH="/home/jianbo/go-ethereum/build/bin/evm"

SOLC_PATH="/usr/bin/solc"

PRESTATE_PATH="/home/jianbo/go-ethereum/taint_scripts/genesis-example.json"
OYENTE_PATH = "~/Re-entrancy/oyente/oyente.py"
COLOR_GREEN="#BFFFBF"
COLOR_RED="#FFBFBF"
COLOR_GREY="#DFDFDF"

HISTORY_LOCAL_PATH="/home/jianbo/go-ethereum/taint_web/history/"
HISTORY_URL="http://easyflow.cc/history/"
